package com.example.myapplication;

public abstract class Entry {
    private String name;
    private double calories;

    public Entry(String name, double calories) {
        this.name = name;
        this.calories = calories;
    }

    public String getFoodName() {
        return name;
    }

    public void setFoodName(String foodName) {
        this.name = foodName;
    }

    public void setCalories(double calories) {
        this.calories = calories;
    }

    public double getCalories() {
        return calories;
    }

    public abstract String getDetails();
}